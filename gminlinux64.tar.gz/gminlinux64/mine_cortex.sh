#!/bin/sh
./miner --algo cortex --server ctxc.2miners.com:2222 --user 0xb7eb4c0a5ff4d574f1fa21f1a9f316199422c56b
