#!/bin/sh
./miner --algo 144_5 --pers BgoldPoW --server btg.2miners.com:4040 --user GZdx44gPVFX7GfeWXA3kyiuXecym3CWGHi.rig0 --pass x
