#!/bin/sh
./miner --algo eth --server eu.ezil.me:5555 --user 0x321ae4016a6397ee004b3f5f9e6c0a0c1915a05d.zil14atwug5nmdmaa43y970ss39pxzzehzc4qzgrhe
